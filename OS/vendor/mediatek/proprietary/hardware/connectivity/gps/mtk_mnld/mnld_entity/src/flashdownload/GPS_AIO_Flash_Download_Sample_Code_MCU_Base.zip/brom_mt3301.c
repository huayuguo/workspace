/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software is protected by Copyright and the information contained
 *  herein is confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of MediaTek Inc. (C) 2016
 *
 ******************************************************************************/

/*******************************************************************************
 * Filename:
 * ---------
 *  brom_mt3301.cpp
 *
 * Project:
 * --------
 *  BootRom Library
 *
 * Description:
 * ------------
 *  BootRom communication functions implementation which are used to sync with BootRom.
 *
 *******************************************************************************/
#include <stdio.h>
#include "flashtool.h"
#include "gps_uart.h"
#include "brom_base.h"
#include "SW_TYPES.h"



// MT3301 BootRom Start Command
#define MT3301_BOOT_ROM_START_CMD1      0xA0
#define MT3301_BOOT_ROM_START_CMD2      0x0A
#define MT3301_BOOT_ROM_START_CMD3      0x50
#define MT3301_BOOT_ROM_START_CMD4      0x05

#define NMEA_START_CMD1         '$'
#define NMEA_START_CMD2         'P'
#define NMEA_START_CMD3         'M'
#define NMEA_START_CMD4         'T'
#define NMEA_START_CMD5         'K'
#define NMEA_START_CMD6         '1'
#define NMEA_START_CMD7         '8'
#define NMEA_START_CMD8         '0'
#define NMEA_START_CMD9         '*'
#define NMEA_START_CMD10        '3'
#define NMEA_START_CMD11        'B'
#define NMEA_START_CMD12      0x0D
#define NMEA_START_CMD13      0x0A


static const unsigned char MT3301_BOOT_ROM_START_CMD[] =
{
   MT3301_BOOT_ROM_START_CMD1,
   MT3301_BOOT_ROM_START_CMD2,
   MT3301_BOOT_ROM_START_CMD3,
   MT3301_BOOT_ROM_START_CMD4
};                              

static unsigned char NMEA_START_CMD[] =
{
   NMEA_START_CMD1,
   NMEA_START_CMD2,
   NMEA_START_CMD3,
   NMEA_START_CMD4,
   NMEA_START_CMD5,
   NMEA_START_CMD6,
   NMEA_START_CMD7,
   NMEA_START_CMD8,
   NMEA_START_CMD9,
   NMEA_START_CMD10, 
   NMEA_START_CMD11, 
   NMEA_START_CMD12, 
   NMEA_START_CMD13 
};                              
                                     

/*******************************************************************************
 * Function name:
 * ---------
 *  BRom_StartCmd
 *
 * Description:
 * ------------
 *  This funciton is used to send SYNC_CHAR to build connection with bootRom.
 *  The communication flow please refer to the BromDLL document.
 *  'BL_PRINT' is a sample to output debug log.
 *
 * Input:
 * --------
 *  arg: download arguments structure includes callback function and parameter. 
 *
 *******************************************************************************/
int BRom_StartCmd(GPS_Download_Arg arg)
{
	unsigned char data8;
	unsigned long i;
	unsigned char tmp8;
	unsigned long cnt = 0;
	
	//BL_PRINT(LOG_DEBUG, "[FUNET]Send PMTK180 to force MT3333/39 into boot rom mode \n\r");
	
	//Send PMTK180 to force 3333 into boot rom
	GPS_UART_PutByte_Buffer((unsigned long *)NMEA_START_CMD, sizeof(NMEA_START_CMD));
    	
	//delay 500ms. 
	GPS_UART_Delay();
	    
	//BL_PRINT(LOG_DEBUG, "[FUNET]Send first sync char \n\r");
	cnt = 0;
	while(1)
	{
		
		GPS_UART_PutByte(MT3301_BOOT_ROM_START_CMD[0]); //First start command sync char
		if(1 == GPS_UART_GetByte_NO_TIMEOUT(&data8))
		{
			 tmp8 = 0x5F;
			 //BL_PRINT(LOG_DEBUG, "[FUNET]Received data:%x \n\r", data8);
			 if(tmp8 == data8)
			 {
				 //BL_PRINT(LOG_DEBUG, "[FUNET] First char sync ok. \n\r");
				 goto SECOND_CHAR;	
			 }
		}
		else
		{
			//BL_PRINT(LOG_DEBUG, "[FUNET]No data received \n\r");
		}
		
		cnt++;
		if (cnt > 50000)
		{
			//BL_PRINT(LOG_DEBUG, "[FUNET] First char sync timeout. \n\r");
			return 1;
		}
	}

	
SECOND_CHAR:
	//BL_PRINT(LOG_DEBUG, "[FUNET]Sync second char \n\r");

	i = 1;
	GPS_UART_PutByte(MT3301_BOOT_ROM_START_CMD[i]); //2nd sync char
	tmp8 = 0xF5; // ~MT3301_BOOT_ROM_START_CMD[i]
	data8 = GPS_UART_GetByte();
	if(tmp8 != data8)
	{
		//BL_PRINT(LOG_DEBUG, "[FUNET]Wrong ack data received:%x \n\r", data8);
		return 1;
	}

	//BL_PRINT(LOG_DEBUG, "[FUNET]Sync third char \n\r");
	i = 2;
	GPS_UART_PutByte(MT3301_BOOT_ROM_START_CMD[i]); //3rd sync char
	tmp8 = 0xAF;
	data8 = GPS_UART_GetByte();
	if(tmp8 != data8)
	{
		//BL_PRINT(LOG_DEBUG, "[FUNET]Wrong ack data received:%x \n\r", data8);
		return 1;
	}

	//BL_PRINT(LOG_DEBUG, "[FUNET]Sync forth char \n\r");
	i = 3;
	GPS_UART_PutByte(MT3301_BOOT_ROM_START_CMD[i]); //4th sync char
	tmp8 = 0xFA;
	data8 = GPS_UART_GetByte();
	if(tmp8 != data8)
	{
		//BL_PRINT(LOG_DEBUG, "[FUNET]Wrong ack data received:%x \n\r", data8);
		return 1;
	}

    return 0;
}


/*******************************************************************************
 * Function name:
 * ---------
 *  Boot_FlashTool
 *
 * Description:
 * ------------
 *  This funciton is used to build connection with bootRom and download DA to target.
 *  The communication flow please refer to the BromDLL document.
 *  'BL_PRINT' is a sample to output debug log.
 *
 * Input:
 * --------
 *  arg: download arguments structure includes callback function and parameter. 
 *  p_arg: download arguments structure includes start address, DA buffer and DA length.
 *
 *******************************************************************************/
int Boot_FlashTool(const s_BOOT_FLASHTOOL_ARG  *p_arg, GPS_Download_Arg arg)
{   
   // check data
   if( NULL == p_arg )
      return BROM_INVALID_ARGUMENTS;

   //BL_PRINT(LOG_DEBUG, "[FUNET]Enter BRom_StartCmd \n\r");

   // send start command 
   if( BRom_StartCmd(arg) )
   {
       return BROM_CMD_START_FAIL;
   }
   //BL_PRINT(LOG_DEBUG, "[FUNET]Start Command Sync Done \n\r");

   if(BRom_WriteBuf(arg, p_arg->m_da_start_addr, p_arg->m_da_buf, p_arg->m_da_len))
   {
      return BROM_DOWNLOAD_DA_FAIL;
   }

   //BL_PRINT(LOG_DEBUG, "[FUNET]Boot_FlashTool: BRom_WriteBuf() Pass! \n\r");

   // jump to m_da_start_addr to execute DA code on Internal SRAM 
   if(BRom_JumpCmd( arg, p_arg->m_da_start_addr ))
      return BROM_CMD_JUMP_FAIL;
   //BL_PRINT(LOG_DEBUG, "[FUNET]Boot_FlashTool: BRom_JumpCmd() Pass! \n\r");
   return BROM_OK;
}
//------------------------------------------------------------------------------
